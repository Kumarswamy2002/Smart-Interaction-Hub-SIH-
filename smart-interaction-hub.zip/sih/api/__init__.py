"""FastAPI REST Gateway package."""
